export const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';
// Token strategy: JWT kept in localStorage and sent as a Bearer header. Simple, immune to CSRF,
// but readable by any XSS. React escapes output by default; never render untrusted HTML.
export const getToken = () => localStorage.getItem('token');
export async function api(path, { method = 'GET', body, form } = {}) {
  const headers = {};
  if (getToken()) headers.Authorization = `Bearer ${getToken()}`;
  if (body) headers['Content-Type'] = 'application/json';
  const res = await fetch(`${API_URL}/api${path}`, { method, headers, body: form || (body ? JSON.stringify(body) : undefined) });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) { const e = new Error(json.errors?.map((x) => `${x.field}: ${x.message}`).join('; ') || json.message || 'Request failed'); e.status = res.status; throw e; }
  return json;
}
