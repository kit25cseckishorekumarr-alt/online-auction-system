export const inr = (paise) => (paise / 100).toLocaleString('en-IN', { style: 'currency', currency: 'INR' });
export const toPaise = (rupees) => Math.round(Number(rupees) * 100);
export const fmtDate = (d) => new Date(d).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
