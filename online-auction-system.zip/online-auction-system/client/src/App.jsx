import { Routes, Route, Link } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import Protected from './components/Guards.jsx';
import { Home, Listings, AuctionDetail } from './pages/Public.jsx';
import { Login, Register, Profile } from './pages/Account.jsx';
import { AuctionForm, MyListings } from './pages/Seller.jsx';
import { Dashboard, MyBids, Won } from './pages/Buyer.jsx';
import { AdminDashboard, ManageUsers, ManageAuctions } from './pages/Admin.jsx';
const NotFound = () => <div className="wrap center"><h1>404</h1><p>Page not found.</p><Link className="btn" to="/">Go home</Link></div>;
export default function App() {
  const P = (el, roles) => <Protected roles={roles}>{el}</Protected>;
  return (<><Navbar /><main className="wrap">
    <Routes>
      <Route path="/" element={<Home />} /><Route path="/auctions" element={<Listings />} /><Route path="/auctions/:id" element={<AuctionDetail />} />
      <Route path="/login" element={<Login />} /><Route path="/register" element={<Register />} />
      <Route path="/profile" element={P(<Profile />)} />
      <Route path="/dashboard" element={P(<Dashboard />, ['buyer', 'seller'])} />
      <Route path="/my-bids" element={P(<MyBids />, ['buyer'])} /><Route path="/won" element={P(<Won />, ['buyer'])} />
      <Route path="/my-listings" element={P(<MyListings />, ['seller'])} />
      <Route path="/create" element={P(<AuctionForm />, ['seller'])} /><Route path="/auctions/:id/edit" element={P(<AuctionForm />, ['seller', 'admin'])} />
      <Route path="/admin" element={P(<AdminDashboard />, ['admin'])} /><Route path="/admin/users" element={P(<ManageUsers />, ['admin'])} /><Route path="/admin/auctions" element={P(<ManageAuctions />, ['admin'])} />
      <Route path="*" element={<NotFound />} />
    </Routes></main></>);
}
