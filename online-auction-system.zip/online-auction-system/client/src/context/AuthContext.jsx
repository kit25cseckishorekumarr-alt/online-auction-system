import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { api, getToken } from '../services/api.js';
const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!getToken());
  const [toast, setToast] = useState(null);
  const notify = useCallback((message, type = 'ok') => { setToast({ message, type }); setTimeout(() => setToast(null), 3500); }, []);
  useEffect(() => { if (!getToken()) return; api('/auth/me').then((r) => setUser(r.data)).catch(() => localStorage.removeItem('token')).finally(() => setLoading(false)); }, []);
  const authenticate = async (path, body) => { const r = await api(path, { method: 'POST', body }); localStorage.setItem('token', r.data.token); setUser(r.data.user); return r.data.user; };
  const logout = () => { localStorage.removeItem('token'); setUser(null); };
  return (<Ctx.Provider value={{ user, setUser, loading, authenticate, logout, notify }}>
    {children}{toast && <div role="status" className={`toast ${toast.type}`}>{toast.message}</div>}</Ctx.Provider>);
}
