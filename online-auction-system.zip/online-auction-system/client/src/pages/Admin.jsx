import { useEffect, useState } from 'react';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.jsx';
import { inr, fmtDate } from '../utils/format.js';
export function AdminDashboard() {
  const [d, setD] = useState(null); const [err, setErr] = useState('');
  useEffect(() => { api('/admin/dashboard').then((r) => setD(r.data)).catch((e) => setErr(e.message)); }, []);
  if (err) return <p className="error">{err}</p>; if (!d) return <p>Loading…</p>;
  return (<><h1>Admin dashboard</h1><div className="stats"><div><b>{d.totalUsers}</b>Users</div><div><b>{d.totalAuctions}</b>Auctions</div><div><b>{d.activeAuctions}</b>Active</div><div><b>{d.completedAuctions}</b>Completed</div></div>
    <h2>Recent bids</h2>{d.recentBids.length === 0 ? <p className="muted">No bids yet.</p> : <table><thead><tr><th>Bidder</th><th>Auction</th><th>Amount</th><th>Time</th></tr></thead><tbody>{d.recentBids.map((b) => <tr key={b._id}><td>{b.bidderId?.name}</td><td>{b.auctionId?.title}</td><td>{inr(b.amount)}</td><td>{fmtDate(b.createdAt)}</td></tr>)}</tbody></table>}</>);
}
export function ManageUsers() {
  const [users, setUsers] = useState(null); const { notify } = useAuth();
  const load = () => api('/admin/users').then((r) => setUsers(r.data)); useEffect(() => { load(); }, []);
  const toggle = async (u) => { const next = u.accountStatus === 'active' ? 'suspended' : 'active'; if (!window.confirm(`Set ${u.name} to ${next}?`)) return;
    try { await api(`/admin/users/${u._id}/status`, { method: 'PATCH', body: { accountStatus: next } }); notify('Updated'); load(); } catch (e) { notify(e.message, 'err'); } };
  if (!users) return <p>Loading…</p>;
  return (<><h1>Manage users</h1><table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th /></tr></thead><tbody>{users.map((u) => <tr key={u._id}><td>{u.name}</td><td>{u.email}</td><td>{u.role}</td><td>{u.accountStatus}</td><td>{u.role !== 'admin' && <button className="link" onClick={() => toggle(u)}>{u.accountStatus === 'active' ? 'Suspend' : 'Reactivate'}</button>}</td></tr>)}</tbody></table></>);
}
export function ManageAuctions() {
  const [items, setItems] = useState(null); const { notify } = useAuth();
  const load = () => api('/admin/auctions').then((r) => setItems(r.data)); useEffect(() => { load(); }, []);
  const remove = async (a) => { if (!window.confirm(`Remove "${a.title}"? It will be cancelled.`)) return; try { await api(`/admin/auctions/${a._id}`, { method: 'DELETE' }); notify('Auction cancelled'); load(); } catch (e) { notify(e.message, 'err'); } };
  if (!items) return <p>Loading…</p>;
  return (<><h1>Manage auctions</h1><table><thead><tr><th>Title</th><th>Seller</th><th>Status</th><th>Bids</th><th>Ends</th><th /></tr></thead><tbody>{items.map((a) => <tr key={a._id}><td>{a.title}</td><td>{a.sellerId?.name}</td><td><span className={`badge ${a.status}`}>{a.status}</span></td><td>{a.bidCount}</td><td>{fmtDate(a.endTime)}</td><td>{a.status !== 'cancelled' && <button className="link danger" onClick={() => remove(a)}>Remove</button>}</td></tr>)}</tbody></table></>);
}
