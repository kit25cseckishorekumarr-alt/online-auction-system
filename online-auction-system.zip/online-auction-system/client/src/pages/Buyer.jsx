import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.jsx';
import { inr, fmtDate } from '../utils/format.js';
import { MyListings } from './Seller.jsx';
const useGet = (p) => { const [d, setD] = useState(null); const [e, setE] = useState(''); useEffect(() => { api(p).then((r) => setD(r.data)).catch((x) => setE(x.message)); }, [p]); return [d, e]; };
export function MyBids() {
  const [bids, err] = useGet('/bids/my-bids');
  if (err) return <p className="error">{err}</p>; if (!bids) return <p>Loading…</p>;
  return (<><h1>My bids</h1>{bids.length === 0 ? <p className="muted">You have not placed any bids.</p> :
    <table><thead><tr><th>Auction</th><th>My bid</th><th>Placed</th><th>Standing</th></tr></thead><tbody>{bids.map((b) => { const a = b.auctionId; const lead = a && b.amount === a.currentHighestBid;
      return <tr key={b._id}><td>{a ? <Link to={`/auctions/${a._id}`}>{a.title}</Link> : 'Removed'}</td><td>{inr(b.amount)}</td><td>{fmtDate(b.createdAt)}</td><td>{a?.status === 'live' ? (lead ? 'Highest' : 'Outbid') : a?.status}</td></tr>; })}</tbody></table>}</>);
}
export function Won() {
  const [wins, err] = useGet('/bids/my-wins');
  if (err) return <p className="error">{err}</p>; if (!wins) return <p>Loading…</p>;
  return (<><h1>Won auctions</h1><p className="muted">Winning does not mean payment is complete; payments are not processed by this app.</p>{wins.length === 0 ? <p className="muted">No wins yet.</p> :
    <table><thead><tr><th>Item</th><th>Winning bid</th><th>Ended</th><th>Payment</th></tr></thead><tbody>{wins.map((a) => <tr key={a._id}><td><Link to={`/auctions/${a._id}`}>{a.title}</Link></td><td>{inr(a.currentHighestBid)}</td><td>{fmtDate(a.endTime)}</td><td>{a.paymentStatus.replace('_', ' ')}</td></tr>)}</tbody></table>}</>);
}
export function Dashboard() {
  const { user } = useAuth();
  const [bids] = useGet(user.role === 'buyer' ? '/bids/my-bids' : '/users/me');
  const [wins] = useGet(user.role === 'buyer' ? '/bids/my-wins' : '/users/me');
  if (user.role === 'seller') return <><h1>Seller dashboard</h1><p>Welcome, {user.name}.</p><MyListings /></>;
  const active = (bids || []).filter((b) => b.auctionId?.status === 'live');
  return (<><h1>Buyer dashboard</h1><p>Welcome, {user.name} ({user.email}).</p>
    <div className="stats"><div><b>{bids ? active.length : '…'}</b>Active bids</div><div><b>{wins ? wins.length : '…'}</b>Auctions won</div><div><b>{bids ? bids.length : '…'}</b>Total bids</div></div>
    <Link className="btn" to="/my-bids">My bids</Link> <Link className="btn" to="/won">Won auctions</Link></>);
}
