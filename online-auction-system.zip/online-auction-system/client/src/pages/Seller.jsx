import { useEffect, useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.jsx';
import { inr, toPaise, fmtDate } from '../utils/format.js';
const local = (d) => { const x = new Date(d); x.setMinutes(x.getMinutes() - x.getTimezoneOffset()); return x.toISOString().slice(0, 16); };
export function AuctionForm() {
  const { id } = useParams(); const nav = useNavigate(); const { notify } = useAuth(); const [err, setErr] = useState('');
  const [f, setF] = useState({ title: '', description: '', category: '', startingPrice: '', minimumBidIncrement: '', startTime: local(new Date()), endTime: local(Date.now() + 86400e3) }); const [file, setFile] = useState(null);
  useEffect(() => { if (id) api(`/auctions/${id}`).then(({ data: a }) => setF({ title: a.title, description: a.description, category: a.category, startingPrice: a.startingPrice / 100, minimumBidIncrement: a.minimumBidIncrement / 100, startTime: local(a.startTime), endTime: local(a.endTime) })).catch((e) => setErr(e.message)); }, [id]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => { e.preventDefault(); setErr('');
    const fd = new FormData();
    Object.entries({ ...f, startingPrice: toPaise(f.startingPrice), minimumBidIncrement: toPaise(f.minimumBidIncrement), startTime: new Date(f.startTime).toISOString(), endTime: new Date(f.endTime).toISOString() }).forEach(([k, v]) => fd.append(k, v));
    if (file) fd.append('image', file);
    try { await api(id ? `/auctions/${id}` : '/auctions', { method: id ? 'PATCH' : 'POST', form: fd }); notify(id ? 'Auction updated' : 'Auction created'); nav('/my-listings'); } catch (ex) { setErr(ex.message); } };
  return (<form className="formbox" onSubmit={submit}><h1>{id ? 'Edit auction' : 'Create auction'}</h1>
    <label>Title<input required minLength={3} value={f.title} onChange={set('title')} /></label>
    <label>Description<textarea required minLength={10} value={f.description} onChange={set('description')} /></label>
    <label>Category<input required value={f.category} onChange={set('category')} /></label>
    <label>Starting price (₹)<input type="number" min="1" step="0.01" required value={f.startingPrice} onChange={set('startingPrice')} /></label>
    <label>Minimum bid increment (₹)<input type="number" min="1" step="0.01" required value={f.minimumBidIncrement} onChange={set('minimumBidIncrement')} /></label>
    <label>Start<input type="datetime-local" required value={f.startTime} onChange={set('startTime')} /></label>
    <label>End<input type="datetime-local" required value={f.endTime} onChange={set('endTime')} /></label>
    <label>Image (JPEG/PNG/WebP, max 2 MB)<input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setFile(e.target.files[0])} /></label>
    {err && <p className="error" role="alert">{err}</p>}<button className="btn">Save</button></form>);
}
export function MyListings() {
  const [items, setItems] = useState(null); const { notify } = useAuth();
  const load = () => api('/auctions/mine').then((r) => setItems(r.data));
  useEffect(() => { load(); }, []);
  const del = async (a) => { if (!window.confirm(`Delete "${a.title}"? This cannot be undone.`)) return; try { await api(`/auctions/${a._id}`, { method: 'DELETE' }); notify('Deleted'); load(); } catch (e) { notify(e.message, 'err'); } };
  if (!items) return <p>Loading…</p>;
  return (<><h1>My listings</h1><Link className="btn" to="/create">New auction</Link>
    {items.length === 0 ? <p className="muted">You have not listed anything yet.</p> :
      <table><thead><tr><th>Title</th><th>Status</th><th>Bids</th><th>Current</th><th>Ends</th><th>Winner</th><th /></tr></thead><tbody>{items.map((a) => (
        <tr key={a._id}><td><Link to={`/auctions/${a._id}`}>{a.title}</Link></td><td><span className={`badge ${a.status}`}>{a.status}</span></td><td>{a.bidCount}</td><td>{inr(a.bidCount ? a.currentHighestBid : a.startingPrice)}</td><td>{fmtDate(a.endTime)}</td><td>{a.winnerId?.name || '—'}</td>
          <td>{a.bidCount === 0 && ['upcoming', 'live'].includes(a.status) && <><Link to={`/auctions/${a._id}/edit`}>Edit</Link> <button className="link danger" onClick={() => del(a)}>Delete</button></>}</td></tr>))}</tbody></table>}</>);
}
