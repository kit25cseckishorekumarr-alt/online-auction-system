import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { api } from '../services/api.js';
function AuthForm({ mode }) {
  const { authenticate, notify } = useAuth(); const nav = useNavigate();
  const [f, setF] = useState({ name: '', email: '', password: '', role: 'buyer' }); const [err, setErr] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => { e.preventDefault(); setErr('');
    try { const u = await authenticate(`/auth/${mode}`, mode === 'login' ? { email: f.email, password: f.password } : f); notify(`Welcome, ${u.name}`); nav(u.role === 'admin' ? '/admin' : '/dashboard'); }
    catch (ex) { setErr(ex.message); } };
  return (<form className="formbox" onSubmit={submit}><h1>{mode === 'login' ? 'Log in' : 'Create account'}</h1>
    {mode === 'register' && <label>Name<input required minLength={2} value={f.name} onChange={set('name')} /></label>}
    <label>Email<input type="email" required value={f.email} onChange={set('email')} /></label>
    <label>Password<input type="password" required minLength={8} value={f.password} onChange={set('password')} /></label>
    {mode === 'register' && <label>I want to<select value={f.role} onChange={set('role')}><option value="buyer">Buy (bid on items)</option><option value="seller">Sell (list items)</option></select></label>}
    {err && <p className="error" role="alert">{err}</p>}<button className="btn">{mode === 'login' ? 'Log in' : 'Register'}</button>
    <p className="muted">{mode === 'login' ? <>New here? <Link to="/register">Register</Link></> : <>Have an account? <Link to="/login">Log in</Link></>}</p></form>);
}
export const Login = () => <AuthForm mode="login" />;
export const Register = () => <AuthForm mode="register" />;
export function Profile() {
  const { user, setUser, notify } = useAuth(); const [name, setName] = useState(user.name);
  const save = async (e) => { e.preventDefault(); try { const r = await api('/users/me', { method: 'PATCH', body: { name } }); setUser(r.data); notify('Profile updated'); } catch (ex) { notify(ex.message, 'err'); } };
  return (<form className="formbox" onSubmit={save}><h1>Profile</h1><p>Email: {user.email}<br />Role: {user.role}<br />Status: {user.accountStatus}</p>
    <label>Name<input required minLength={2} value={name} onChange={(e) => setName(e.target.value)} /></label><button className="btn">Save</button></form>);
}
