import { useEffect, useState, useCallback } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api, API_URL } from '../services/api.js';
import { useAuth } from '../context/AuthContext.jsx';
import AuctionCard from '../components/AuctionCard.jsx';
import Countdown from '../components/Countdown.jsx';
import { inr, toPaise, fmtDate } from '../utils/format.js';

export function Home() {
  const [items, setItems] = useState(null);
  useEffect(() => { api('/auctions?status=live&limit=6').then((r) => setItems(r.data)).catch(() => setItems([])); }, []);
  return (<><section className="hero"><h1>Bid. Win. Sell.</h1><p>A simple, fair marketplace for online auctions.</p><Link className="btn" to="/auctions">Browse auctions</Link></section>
    <h2>Ending soon</h2>{!items ? <p>Loading…</p> : items.length === 0 ? <p className="muted">No live auctions right now.</p> : <div className="grid">{items.map((a) => <AuctionCard key={a._id} a={a} />)}</div>}</>);
}

export function Listings() {
  const [f, setF] = useState({ q: '', category: '', status: '', sort: 'endTime', page: 1 });
  const [res, setRes] = useState(null); const [err, setErr] = useState('');
  useEffect(() => { setRes(null); const qs = new URLSearchParams(Object.entries(f).filter(([, v]) => v)).toString();
    api(`/auctions?${qs}`).then(setRes).catch((e) => setErr(e.message)); }, [f]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value, page: 1 });
  return (<><h1>Auctions</h1>
    <div className="filters">
      <label>Search<input value={f.q} onChange={set('q')} placeholder="Product name" /></label>
      <label>Category<input value={f.category} onChange={set('category')} placeholder="e.g. Electronics" /></label>
      <label>Status<select value={f.status} onChange={set('status')}><option value="">Any</option><option value="upcoming">Upcoming</option><option value="live">Live</option><option value="ended">Ended</option></select></label>
      <label>Sort<select value={f.sort} onChange={set('sort')}><option value="endTime">Ending soonest</option><option value="price">Price: low to high</option><option value="-price">Price: high to low</option></select></label>
    </div>
    {err && <p className="error">{err}</p>}
    {!res && !err ? <p>Loading…</p> : res && (res.data.length === 0 ? <p className="muted">No auctions match your filters.</p> :
      <><div className="grid">{res.data.map((a) => <AuctionCard key={a._id} a={a} />)}</div>
        <div className="row center"><button className="btn" disabled={f.page <= 1} onClick={() => setF({ ...f, page: f.page - 1 })}>Prev</button>
          <span>Page {res.meta.page} of {res.meta.pages}</span>
          <button className="btn" disabled={f.page >= res.meta.pages} onClick={() => setF({ ...f, page: f.page + 1 })}>Next</button></div></>)}</>);
}

export function AuctionDetail() {
  const { id } = useParams(); const { user, notify } = useAuth();
  const [a, setA] = useState(null); const [bids, setBids] = useState([]); const [amount, setAmount] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const load = useCallback(() => Promise.all([api(`/auctions/${id}`), api(`/auctions/${id}/bids`)]).then(([x, y]) => { setA(x.data); setBids(y.data); }).catch((e) => setErr(e.message)), [id]);
  useEffect(() => { load(); const t = setInterval(load, 10000); return () => clearInterval(t); }, [load]);
  if (err && !a) return <p className="error">{err}</p>;
  if (!a) return <p>Loading…</p>;
  const min = a.bidCount ? a.currentHighestBid + a.minimumBidIncrement : a.startingPrice;
  const isSeller = user && a.sellerId?._id === user._id;
  const submit = async (e) => { e.preventDefault(); setBusy(true); setErr('');
    try { await api(`/auctions/${id}/bids`, { method: 'POST', body: { amount: toPaise(amount) } }); notify('Bid accepted'); setAmount(''); await load(); }
    catch (ex) { setErr(ex.message); notify('Bid rejected', 'err'); } finally { setBusy(false); } };
  return (<div className="detail">
    <div className="thumb big">{a.imageUrl ? <img src={API_URL + a.imageUrl} alt={a.title} /> : <span>No image</span>}</div>
    <div><span className={`badge ${a.status}`}>{a.status}</span> <span className="muted">{a.category} · Seller: {a.sellerId?.name}</span>
      <h1>{a.title}</h1><p>{a.description}</p>
      <p className="price">{inr(a.bidCount ? a.currentHighestBid : a.startingPrice)} <small>Starting {inr(a.startingPrice)} · increment {inr(a.minimumBidIncrement)}</small></p>
      <p className="muted">Starts {fmtDate(a.startTime)} · Ends {fmtDate(a.endTime)}</p>
      {a.status === 'live' && <p><Countdown target={a.endTime} /></p>}
      {a.status === 'ended' && <p>{a.winnerId ? `Won by ${a.winnerId.name} at ${inr(a.currentHighestBid)} (payment not processed)` : 'Ended with no bids.'}</p>}
      {a.status === 'live' && (!user ? <Link className="btn" to="/login">Log in to bid</Link> : isSeller ? <p className="muted">You cannot bid on your own auction.</p> : user.role === 'admin' ? null :
        <form onSubmit={submit} className="bidform"><label>Your bid (₹, min {inr(min)})<input type="number" step="0.01" min={min / 100} required value={amount} onChange={(e) => setAmount(e.target.value)} /></label>
          <button className="btn" disabled={busy}>{busy ? 'Placing…' : 'Place Bid'}</button></form>)}
      {err && <p className="error" role="alert">{err}</p>}
      <h3>Bid history</h3>{bids.length === 0 ? <p className="muted">No bids yet.</p> :
        <table><thead><tr><th>Bidder</th><th>Amount</th><th>Time</th></tr></thead><tbody>{bids.map((b) => <tr key={b._id}><td>{b.bidderId?.name}</td><td>{inr(b.amount)}</td><td>{fmtDate(b.createdAt)}</td></tr>)}</tbody></table>}
    </div></div>);
}
