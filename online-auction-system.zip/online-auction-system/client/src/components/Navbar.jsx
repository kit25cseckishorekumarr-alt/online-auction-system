import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
export default function Navbar() {
  const { user, logout } = useAuth(); const nav = useNavigate();
  return (
    <header className="nav"><div className="wrap row">
      <Link to="/" className="brand">BidHub</Link>
      <nav aria-label="Main" className="row">
        <NavLink to="/auctions">Auctions</NavLink>
        {user?.role === 'buyer' && <><NavLink to="/dashboard">Dashboard</NavLink><NavLink to="/my-bids">My Bids</NavLink><NavLink to="/won">Won</NavLink></>}
        {user?.role === 'seller' && <><NavLink to="/dashboard">Dashboard</NavLink><NavLink to="/my-listings">My Listings</NavLink><NavLink to="/create">Sell</NavLink></>}
        {user?.role === 'admin' && <><NavLink to="/admin">Admin</NavLink><NavLink to="/admin/users">Users</NavLink><NavLink to="/admin/auctions">Auctions</NavLink></>}
        {user ? <><NavLink to="/profile">{user.name}</NavLink><button className="link" onClick={() => { logout(); nav('/'); }}>Logout</button></>
          : <><NavLink to="/login">Login</NavLink><NavLink to="/register">Register</NavLink></>}
      </nav></div></header>);
}
