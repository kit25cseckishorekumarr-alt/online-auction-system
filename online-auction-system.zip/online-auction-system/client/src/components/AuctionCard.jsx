import { Link } from 'react-router-dom';
import { API_URL } from '../services/api.js';
import { inr } from '../utils/format.js';
import Countdown from './Countdown.jsx';
export default function AuctionCard({ a }) {
  const price = a.bidCount ? a.currentHighestBid : a.startingPrice;
  return (
    <article className="card">
      <div className="thumb">{a.imageUrl ? <img src={API_URL + a.imageUrl} alt={a.title} /> : <span>No image</span>}</div>
      <div className="card-body">
        <span className={`badge ${a.status}`}>{a.status}</span> <span className="muted">{a.category}</span>
        <h3>{a.title}</h3>
        <p className="price">{inr(price)} <small>{a.bidCount ? `${a.bidCount} bids` : 'starting price'}</small></p>
        {a.status === 'live' && <Countdown target={a.endTime} />}
        <Link className="btn" to={`/auctions/${a._id}`}>{a.status === 'live' ? 'Place Bid' : 'View'}</Link>
      </div>
    </article>);
}
