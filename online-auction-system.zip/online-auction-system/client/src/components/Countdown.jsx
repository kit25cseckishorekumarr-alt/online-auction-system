import { useEffect, useState } from 'react';
export default function Countdown({ target, label = 'Ends in' }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, []);
  const s = Math.max(0, Math.floor((new Date(target) - now) / 1000));
  if (s === 0) return <span className="muted">Time is up</span>;
  const d = Math.floor(s / 86400), h = Math.floor(s / 3600) % 24, m = Math.floor(s / 60) % 60;
  return <span className="timer">{label} {d > 0 && `${d}d `}{h}h {m}m {s % 60}s</span>;
}
