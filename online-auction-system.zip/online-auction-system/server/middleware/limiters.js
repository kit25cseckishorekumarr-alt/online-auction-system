const rateLimit = require('express-rate-limit');
const skip = () => process.env.NODE_ENV === 'test';
const make = (windowMs, limit) => rateLimit({ windowMs, limit, skip, standardHeaders: true, legacyHeaders: false,
  message: { success: false, message: 'Too many requests, please try again later' } });
module.exports = { authLimiter: make(15 * 60 * 1000, 30), bidLimiter: make(60 * 1000, 30) };
