const { ZodError } = require('zod');
const notFound = (req, res) => res.status(404).json({ success: false, message: 'Route not found' });
// Centralised error handler: every error leaves the API in the same JSON shape.
// eslint-disable-next-line no-unused-vars
const errorHandler = (err, req, res, next) => {
  if (err instanceof ZodError) {
    return res.status(400).json({ success: false, message: 'Validation failed',
      errors: err.issues.map((i) => ({ field: i.path.join('.'), message: i.message })) });
  }
  if (err.name === 'CastError') return res.status(400).json({ success: false, message: 'Invalid id' });
  if (err.code === 11000) return res.status(409).json({ success: false, message: 'Duplicate value' });
  if (err.name === 'MulterError' || err.isUpload) return res.status(400).json({ success: false, message: err.message });
  const status = err.status || 500;
  if (status === 500) console.error(err);
  res.status(status).json({ success: false, message: status === 500 ? 'Internal server error' : err.message });
};
module.exports = { notFound, errorHandler };
