const multer = require('multer');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');
const dir = path.join(__dirname, '..', 'uploads');
fs.mkdirSync(dir, { recursive: true });
const types = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' };
// Safe uploads: whitelist MIME types, random server-chosen filenames, 2 MB cap, one file.
module.exports = multer({
  storage: multer.diskStorage({
    destination: dir,
    filename: (req, file, cb) => cb(null, crypto.randomBytes(16).toString('hex') + types[file.mimetype]),
  }),
  limits: { fileSize: 2 * 1024 * 1024, files: 1 },
  fileFilter: (req, file, cb) => {
    if (types[file.mimetype]) return cb(null, true);
    const e = new Error('Only JPEG, PNG or WebP images allowed'); e.isUpload = true; cb(e);
  },
});
