const jwt = require('jsonwebtoken');
const User = require('../models/User');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

// Verifies the Bearer token and re-loads the user so suspended accounts lose access immediately.
const authenticate = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) throw new AppError(401, 'Authentication required');
  let payload;
  try { payload = jwt.verify(header.slice(7), process.env.JWT_SECRET); }
  catch { throw new AppError(401, 'Invalid or expired token'); }
  const user = await User.findById(payload.sub);
  if (!user) throw new AppError(401, 'User no longer exists');
  if (user.accountStatus !== 'active') throw new AppError(403, 'Account suspended');
  req.user = user;
  next();
});
const requireRole = (...roles) => (req, res, next) =>
  roles.includes(req.user.role) ? next() : next(new AppError(403, 'You do not have permission for this action'));
module.exports = { authenticate, requireRole };
