// NoSQL injection guard: strips keys beginning with "$" or containing "." from body/query/params.
const clean = (o) => {
  if (!o || typeof o !== 'object') return;
  for (const k of Object.keys(o)) {
    if (k.startsWith('$') || k.includes('.')) delete o[k];
    else clean(o[k]);
  }
};
module.exports = (req, res, next) => { clean(req.body); clean(req.query); clean(req.params); next(); };
