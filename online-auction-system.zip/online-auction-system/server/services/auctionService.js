const Auction = require('../models/Auction');
const Bid = require('../models/Bid');
const AppError = require('../utils/AppError');

// Idempotent: the filter only matches auctions still upcoming/live, so a second run is a no-op.
async function finalizeAuction(id) {
  const top = await Bid.findOne({ auctionId: id }).sort({ amount: -1, createdAt: 1 });
  return Auction.findOneAndUpdate(
    { _id: id, status: { $in: ['upcoming', 'live'] }, endTime: { $lte: new Date() } },
    { status: 'ended', winnerId: top ? top.bidderId : null }, { new: true });
}

// Lazily advances statuses (upcoming -> live -> ended). Called before reads/bids; safe to repeat.
async function syncStatuses() {
  const now = new Date();
  await Auction.updateMany({ status: 'upcoming', startTime: { $lte: now }, endTime: { $gt: now } }, { status: 'live' });
  const due = await Auction.find({ status: { $in: ['upcoming', 'live'] }, endTime: { $lte: now } }).select('_id');
  for (const { _id } of due) await finalizeAuction(_id);
}

// Concurrency control: the price check and the update happen in ONE atomic findOneAndUpdate, so two
// simultaneous equal bids cannot both succeed (the second sees the raised price and fails the filter).
async function placeBid(auctionId, user, amount) {
  await syncStatuses();
  const auction = await Auction.findById(auctionId);
  if (!auction) throw new AppError(404, 'Auction not found');
  if (String(auction.sellerId) === String(user._id)) throw new AppError(403, 'Sellers cannot bid on their own auctions');
  if (auction.status === 'upcoming') throw new AppError(400, 'Auction has not started yet');
  if (auction.status !== 'live') throw new AppError(400, 'Auction is not open for bidding');
  const updated = await Auction.findOneAndUpdate(
    { _id: auctionId, status: 'live', endTime: { $gt: new Date() },
      $expr: { $gte: [amount, { $cond: [{ $eq: ['$bidCount', 0] }, '$startingPrice', { $add: ['$currentHighestBid', '$minimumBidIncrement'] }] }] } },
    { $set: { currentHighestBid: amount, highestBidderId: user._id }, $inc: { bidCount: 1 } }, { new: true });
  if (!updated) {
    const min = auction.bidCount === 0 ? auction.startingPrice : auction.currentHighestBid + auction.minimumBidIncrement;
    throw new AppError(409, `Bid rejected. Minimum acceptable bid is ${min} paise`);
  }
  const bid = await Bid.create({ auctionId, bidderId: user._id, amount });
  return { bid, auction: updated };
}
module.exports = { syncStatuses, finalizeAuction, placeBid };
