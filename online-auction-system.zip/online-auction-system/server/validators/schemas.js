const { z } = require('zod');
const email = z.string().email().max(120);
const password = z.string().min(8).max(72);
const money = z.coerce.number().int().min(100, 'Minimum 100 paise');
const auctionBase = {
  title: z.string().trim().min(3).max(120),
  description: z.string().trim().min(10).max(2000),
  category: z.string().trim().min(2).max(40),
  startingPrice: money, minimumBidIncrement: money,
  startTime: z.coerce.date(), endTime: z.coerce.date(),
};
module.exports = {
  register: z.object({ name: z.string().trim().min(2).max(80), email, password, role: z.enum(['buyer', 'seller']).default('buyer') }),
  login: z.object({ email, password: z.string().min(1).max(72) }),
  profile: z.object({ name: z.string().trim().min(2).max(80) }).strict(),
  createAuction: z.object(auctionBase).refine((d) => d.endTime > d.startTime, { message: 'endTime must be after startTime', path: ['endTime'] }),
  updateAuction: z.object(auctionBase).partial().strict(),
  bid: z.object({ amount: z.coerce.number().int().positive() }),
  listQuery: z.object({
    q: z.string().max(80).optional(), category: z.string().max(40).optional(),
    status: z.enum(['upcoming', 'live', 'ended', 'cancelled']).optional(),
    sort: z.enum(['endTime', 'price', '-price']).default('endTime'),
    page: z.coerce.number().int().min(1).default(1), limit: z.coerce.number().int().min(1).max(50).default(9),
  }),
  userStatus: z.object({ accountStatus: z.enum(['active', 'suspended']) }),
};
