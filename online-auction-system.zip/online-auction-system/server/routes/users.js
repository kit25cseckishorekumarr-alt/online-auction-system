const router = require('express').Router();
const v = require('../validators/schemas');
const asyncHandler = require('../utils/asyncHandler');
const { authenticate } = require('../middleware/auth');
router.use(authenticate);
router.get('/me', (req, res) => res.json({ success: true, data: req.user }));
router.patch('/me', asyncHandler(async (req, res) => {
  req.user.name = v.profile.parse(req.body).name; // role/email/status can never be changed here
  await req.user.save();
  res.json({ success: true, data: req.user });
}));
module.exports = router;
