const router = require('express').Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const v = require('../validators/schemas');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { authenticate } = require('../middleware/auth');
const { authLimiter } = require('../middleware/limiters');
const sign = (u) => jwt.sign({ sub: u._id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '2h' });

router.post('/register', authLimiter, asyncHandler(async (req, res) => {
  const { name, email, password, role } = v.register.parse(req.body); // role limited to buyer|seller
  if (await User.findOne({ email })) throw new AppError(409, 'Email already registered');
  const user = await User.create({ name, email, role, passwordHash: await bcrypt.hash(password, 12) });
  res.status(201).json({ success: true, data: { token: sign(user), user } });
}));
router.post('/login', authLimiter, asyncHandler(async (req, res) => {
  const { email, password } = v.login.parse(req.body);
  const user = await User.findOne({ email }).select('+passwordHash');
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) throw new AppError(401, 'Invalid email or password');
  if (user.accountStatus !== 'active') throw new AppError(403, 'Account suspended');
  res.json({ success: true, data: { token: sign(user), user } });
}));
router.get('/me', authenticate, (req, res) => res.json({ success: true, data: req.user }));
module.exports = router;
