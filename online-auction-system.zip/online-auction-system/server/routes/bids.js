const router = require('express').Router();
const Bid = require('../models/Bid');
const Auction = require('../models/Auction');
const asyncHandler = require('../utils/asyncHandler');
const { authenticate } = require('../middleware/auth');
const { syncStatuses } = require('../services/auctionService');
router.use(authenticate);
router.get('/my-bids', asyncHandler(async (req, res) => {
  await syncStatuses();
  const bids = await Bid.find({ bidderId: req.user._id }).sort({ createdAt: -1 }).limit(200)
    .populate('auctionId', 'title status currentHighestBid highestBidderId endTime');
  res.json({ success: true, data: bids });
}));
router.get('/my-wins', asyncHandler(async (req, res) => {
  await syncStatuses();
  // "won" = highest valid bid at close. Payments are NOT implemented: paymentStatus is always "not_processed".
  const wins = await Auction.find({ winnerId: req.user._id }).sort({ endTime: -1 });
  res.json({ success: true, data: wins.map((a) => ({ ...a.toJSON(), paymentStatus: 'not_processed' })) });
}));
module.exports = router;
