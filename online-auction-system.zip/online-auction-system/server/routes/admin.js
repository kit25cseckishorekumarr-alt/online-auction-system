const router = require('express').Router();
const User = require('../models/User');
const Auction = require('../models/Auction');
const Bid = require('../models/Bid');
const v = require('../validators/schemas');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { authenticate, requireRole } = require('../middleware/auth');
const { syncStatuses } = require('../services/auctionService');
router.use(authenticate, requireRole('admin'));

router.get('/dashboard', asyncHandler(async (req, res) => {
  await syncStatuses();
  const [users, auctions, live, ended, recent] = await Promise.all([
    User.countDocuments(), Auction.countDocuments(), Auction.countDocuments({ status: 'live' }),
    Auction.countDocuments({ status: 'ended' }),
    Bid.find().sort({ createdAt: -1 }).limit(10).populate('bidderId', 'name').populate('auctionId', 'title')]);
  res.json({ success: true, data: { totalUsers: users, totalAuctions: auctions, activeAuctions: live, completedAuctions: ended, recentBids: recent } });
}));
router.get('/users', asyncHandler(async (req, res) =>
  res.json({ success: true, data: await User.find().sort({ createdAt: -1 }).limit(500) })));
router.patch('/users/:id/status', asyncHandler(async (req, res) => {
  const { accountStatus } = v.userStatus.parse(req.body);
  const u = await User.findById(req.params.id);
  if (!u) throw new AppError(404, 'User not found');
  if (u.role === 'admin') throw new AppError(400, 'Admin accounts cannot be suspended');
  u.accountStatus = accountStatus; await u.save();
  res.json({ success: true, data: u });
}));
router.get('/auctions', asyncHandler(async (req, res) => {
  await syncStatuses();
  res.json({ success: true, data: await Auction.find().sort({ createdAt: -1 }).limit(500).populate('sellerId', 'name') });
}));
// Admin removal = cancel (keeps bid records for audit) rather than hard delete.
router.delete('/auctions/:id', asyncHandler(async (req, res) => {
  const a = await Auction.findByIdAndUpdate(req.params.id, { status: 'cancelled', winnerId: null }, { new: true });
  if (!a) throw new AppError(404, 'Auction not found');
  res.json({ success: true, message: 'Auction cancelled', data: a });
}));
module.exports = router;
