const router = require('express').Router();
const Auction = require('../models/Auction');
const Bid = require('../models/Bid');
const v = require('../validators/schemas');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const upload = require('../middleware/upload');
const { authenticate, requireRole } = require('../middleware/auth');
const { bidLimiter } = require('../middleware/limiters');
const { syncStatuses, placeBid } = require('../services/auctionService');
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

router.get('/', asyncHandler(async (req, res) => {
  await syncStatuses();
  const { q, category, status, sort, page, limit } = v.listQuery.parse(req.query);
  const filter = { status: status || { $ne: 'cancelled' } };
  if (q) filter.title = { $regex: esc(q), $options: 'i' };
  if (category) filter.category = category;
  const sortBy = { endTime: { endTime: 1 }, price: { currentHighestBid: 1 }, '-price': { currentHighestBid: -1 } }[sort];
  const [items, total] = await Promise.all([
    Auction.find(filter).sort(sortBy).skip((page - 1) * limit).limit(limit).populate('sellerId', 'name'),
    Auction.countDocuments(filter)]);
  res.json({ success: true, data: items, meta: { page, limit, total, pages: Math.ceil(total / limit) } });
}));

router.get('/mine', authenticate, requireRole('seller', 'admin'), asyncHandler(async (req, res) => {
  await syncStatuses();
  res.json({ success: true, data: await Auction.find({ sellerId: req.user._id }).sort({ createdAt: -1 }).populate('winnerId', 'name') });
}));

router.get('/:id', asyncHandler(async (req, res) => {
  await syncStatuses();
  const a = await Auction.findById(req.params.id).populate('sellerId', 'name').populate('winnerId', 'name');
  if (!a) throw new AppError(404, 'Auction not found');
  res.json({ success: true, data: a });
}));

router.post('/', authenticate, requireRole('seller'), upload.single('image'), asyncHandler(async (req, res) => {
  const d = v.createAuction.parse(req.body);
  if (d.endTime <= new Date()) throw new AppError(400, 'endTime must be in the future');
  const a = await Auction.create({ ...d, sellerId: req.user._id, // seller comes from the token, never the body
    imageUrl: req.file ? `/uploads/${req.file.filename}` : '' });
  await syncStatuses();
  res.status(201).json({ success: true, data: await Auction.findById(a._id) });
}));

const ownOrAdmin = async (req) => {
  const a = await Auction.findById(req.params.id);
  if (!a) throw new AppError(404, 'Auction not found');
  if (String(a.sellerId) !== String(req.user._id) && req.user.role !== 'admin') throw new AppError(403, 'Not your auction');
  if (a.bidCount > 0 && req.user.role !== 'admin') throw new AppError(409, 'Cannot modify an auction after bidding has begun');
  return a;
};
router.patch('/:id', authenticate, upload.single('image'), asyncHandler(async (req, res) => {
  const a = await ownOrAdmin(req);
  if (a.status === 'ended' || a.status === 'cancelled') throw new AppError(409, 'Auction is closed');
  Object.assign(a, v.updateAuction.parse(req.body));
  if (a.endTime <= a.startTime) throw new AppError(400, 'endTime must be after startTime');
  if (req.file) a.imageUrl = `/uploads/${req.file.filename}`;
  await a.save();
  res.json({ success: true, data: a });
}));
router.delete('/:id', authenticate, asyncHandler(async (req, res) => {
  const a = await ownOrAdmin(req);
  await a.deleteOne();
  await Bid.deleteMany({ auctionId: a._id });
  res.json({ success: true, message: 'Auction deleted' });
}));

router.post('/:id/bids', authenticate, bidLimiter, asyncHandler(async (req, res) => {
  const { amount } = v.bid.parse(req.body);
  const { bid, auction } = await placeBid(req.params.id, req.user, amount);
  res.status(201).json({ success: true, message: 'Bid accepted', data: { bid, currentHighestBid: auction.currentHighestBid } });
}));
router.get('/:id/bids', asyncHandler(async (req, res) => {
  const bids = await Bid.find({ auctionId: req.params.id }).sort({ amount: -1 }).limit(100).populate('bidderId', 'name');
  res.json({ success: true, data: bids });
}));
module.exports = router;
