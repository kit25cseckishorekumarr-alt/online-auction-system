require('dotenv').config();
const bcrypt = require('bcrypt');
const mongoose = require('mongoose');
const User = require('../models/User');
(async () => {
  await mongoose.connect(process.env.MONGODB_URI);
  const email = process.env.ADMIN_EMAIL, pw = process.env.ADMIN_PASSWORD;
  if (!email || !pw) throw new Error('Set ADMIN_EMAIL and ADMIN_PASSWORD');
  await User.updateOne({ email }, { $setOnInsert: { name: 'Administrator', email, role: 'admin', passwordHash: await bcrypt.hash(pw, 12) } }, { upsert: true });
  console.log('Admin ready:', email); await mongoose.disconnect();
})().catch((e) => { console.error(e.message); process.exit(1); });
