const mongoose = require('mongoose');
// All money fields are integer paise (1 INR = 100 paise).
const auctionSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 120 },
  description: { type: String, required: true, trim: true, maxlength: 2000 },
  category: { type: String, required: true, trim: true, maxlength: 40 },
  imageUrl: { type: String, default: '' },
  sellerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  startingPrice: { type: Number, required: true, min: 100, validate: Number.isInteger },
  currentHighestBid: { type: Number, default: 0, validate: Number.isInteger },
  highestBidderId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  bidCount: { type: Number, default: 0 },
  minimumBidIncrement: { type: Number, required: true, min: 100, validate: Number.isInteger },
  startTime: { type: Date, required: true },
  endTime: { type: Date, required: true },
  status: { type: String, enum: ['upcoming', 'live', 'ended', 'cancelled'], default: 'upcoming' },
  winnerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
}, { timestamps: true });
auctionSchema.index({ status: 1, endTime: 1 });
auctionSchema.index({ sellerId: 1 });
auctionSchema.index({ winnerId: 1 });
module.exports = mongoose.model('Auction', auctionSchema);
