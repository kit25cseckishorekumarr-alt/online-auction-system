const mongoose = require('mongoose');
const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, minlength: 2, maxlength: 80 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true, select: false },
  role: { type: String, enum: ['buyer', 'seller', 'admin'], default: 'buyer' },
  accountStatus: { type: String, enum: ['active', 'suspended'], default: 'active' },
}, { timestamps: true });
userSchema.set('toJSON', { transform: (doc, ret) => { delete ret.passwordHash; delete ret.__v; return ret; } });
module.exports = mongoose.model('User', userSchema);
