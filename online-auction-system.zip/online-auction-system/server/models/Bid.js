const mongoose = require('mongoose');
const bidSchema = new mongoose.Schema({
  auctionId: { type: mongoose.Schema.Types.ObjectId, ref: 'Auction', required: true },
  bidderId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  amount: { type: Number, required: true, min: 1, validate: Number.isInteger },
}, { timestamps: { createdAt: true, updatedAt: false } });
bidSchema.index({ auctionId: 1, amount: -1 });
bidSchema.index({ bidderId: 1, createdAt: -1 });
// Bids are append-only: block updates at the model level (no API route edits bids either).
['updateOne', 'updateMany', 'findOneAndUpdate'].forEach((op) =>
  bidSchema.pre(op, function () { throw new Error('Bids are immutable'); }));
module.exports = mongoose.model('Bid', bidSchema);
