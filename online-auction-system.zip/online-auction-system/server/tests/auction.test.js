process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'test-secret';
const { test, before, after } = require('node:test');
const assert = require('node:assert');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const { MongoMemoryServer } = require('mongodb-memory-server');
const request = require('supertest');
const app = require('../app');
const Auction = require('../models/Auction');
const User = require('../models/User');
const { syncStatuses } = require('../services/auctionService');
let mongod; const api = () => request(app);
const reg = async (name, role) => (await api().post('/api/auth/register').send({ name, email: `${name}@t.com`, password: 'password123', role })).body.data;
const mk = (t) => api().post('/api/auctions').set('Authorization', `Bearer ${t}`)
  .field('title', 'Vintage Clock').field('description', 'A lovely old clock').field('category', 'Antiques')
  .field('startingPrice', 10000).field('minimumBidIncrement', 500)
  .field('startTime', new Date(Date.now() - 1000).toISOString()).field('endTime', new Date(Date.now() + 3600e3).toISOString());
before(async () => { mongod = await MongoMemoryServer.create(); await mongoose.connect(mongod.getUri()); });
after(async () => { await mongoose.disconnect(); await mongod.stop(); });

test('register, duplicate, login valid/invalid, protected route', async () => {
  const s = await reg('sel', 'seller');
  assert.ok(s.token); assert.strictEqual(s.user.passwordHash, undefined);
  assert.strictEqual((await api().post('/api/auth/register').send({ name: 'sel', email: 'sel@t.com', password: 'password123' })).status, 409);
  assert.strictEqual((await api().post('/api/auth/login').send({ email: 'sel@t.com', password: 'password123' })).status, 200);
  assert.strictEqual((await api().post('/api/auth/login').send({ email: 'sel@t.com', password: 'wrong' })).status, 401);
  assert.strictEqual((await api().get('/api/auth/me')).status, 401);
});
test('role restrictions: buyer cannot create auction or reach admin', async () => {
  const b = await reg('buy', 'buyer');
  assert.strictEqual((await mk(b.token)).status, 403);
  assert.strictEqual((await api().get('/api/admin/users').set('Authorization', `Bearer ${b.token}`)).status, 403);
});
test('validation: bad auction rejected', async () => {
  const s = await reg('sel3', 'seller');
  const r = await api().post('/api/auctions').set('Authorization', `Bearer ${s.token}`).field('title', 'x');
  assert.strictEqual(r.status, 400);
});
test('bidding rules, concurrency, completion, no-bid auction', async () => {
  const s = await reg('sel2', 'seller'), b1 = await reg('b1', 'buyer'), b2 = await reg('b2', 'buyer');
  const created = await mk(s.token); assert.strictEqual(created.status, 201);
  const id = created.body.data._id;
  const bid = (t, amount) => api().post(`/api/auctions/${id}/bids`).set('Authorization', `Bearer ${t}`).send({ amount });
  assert.strictEqual((await bid(s.token, 20000)).status, 403);
  assert.strictEqual((await bid(b1.token, 5000)).status, 409);
  assert.strictEqual((await bid(b1.token, 10000)).status, 201);
  assert.strictEqual((await bid(b2.token, 10200)).status, 409);
  const results = await Promise.all([1, 2, 3, 4, 5].map(() => bid(b2.token, 20000)));
  assert.strictEqual(results.filter((r) => r.status === 201).length, 1);
  await Auction.updateOne({ _id: id }, { endTime: new Date(Date.now() - 1000) });
  assert.strictEqual((await bid(b1.token, 99999)).status, 400);
  await syncStatuses(); await syncStatuses();
  const a = await Auction.findById(id);
  assert.strictEqual(a.status, 'ended'); assert.strictEqual(String(a.winnerId), b2.user._id);
  const empty = (await mk(s.token)).body.data._id;
  await Auction.updateOne({ _id: empty }, { endTime: new Date(Date.now() - 1000) });
  await syncStatuses();
  const e = await Auction.findById(empty); assert.strictEqual(e.status, 'ended'); assert.strictEqual(e.winnerId, null);
});
test('admin can suspend a user; suspended user is blocked', async () => {
  const u = await reg('victim', 'buyer');
  await User.create({ name: 'Admin', email: 'admin@t.com', role: 'admin', passwordHash: await bcrypt.hash('password123', 4) });
  const login = await api().post('/api/auth/login').send({ email: 'admin@t.com', password: 'password123' });
  const r = await api().patch(`/api/admin/users/${u.user._id}/status`).set('Authorization', `Bearer ${login.body.data.token}`).send({ accountStatus: 'suspended' });
  assert.strictEqual(r.status, 200);
  assert.strictEqual((await api().get('/api/auth/me').set('Authorization', `Bearer ${u.token}`)).status, 403);
});
