# Architecture

React (Vite) SPA -> REST/JSON -> Express -> Mongoose -> MongoDB.

- **Auth**: bcrypt (cost 12) hashes; JWT (default 2h) in `Authorization` header. The client keeps it in localStorage: simple and CSRF-immune, but an XSS bug could steal it. Alternative: HttpOnly+Secure+SameSite cookie with CSRF protection.
- **Money**: integer paise everywhere; formatted as INR only in the UI.
- **Statuses**: `upcoming -> live -> ended` (or `cancelled`) are advanced lazily by `syncStatuses()` on reads/bids, not by a background job. Finalization is idempotent (guarded `findOneAndUpdate`).
- **Concurrency**: `placeBid` validates and raises the price in one atomic conditional update (no transactions/replica set needed). The Bid record is inserted afterwards; if that insert failed, the auction price could be ahead of the bid log (rare; a transaction on a replica set would close this gap).
- **Security**: helmet, CORS to `CLIENT_URL`, 10kb JSON limit, `$`-key stripping, zod validation, rate limits on auth/bids, upload whitelist (JPEG/PNG/WebP, 2MB, random names).
