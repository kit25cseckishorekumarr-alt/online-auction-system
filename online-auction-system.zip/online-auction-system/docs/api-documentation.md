# API Documentation

Base URL: `http://localhost:5000/api`. All responses: `{ "success": true|false, "data"?, "message"?, "errors"? }`.
Auth: `Authorization: Bearer <JWT>`. **All money values are integer paise** (₹1 = 100).

| Method & path | Access | Notes |
|---|---|---|
| POST `/auth/register` | public | body: name, email, password (8+), role `buyer`\|`seller` |
| POST `/auth/login` | public | returns `{ token, user }` |
| GET `/auth/me` | any user | |
| GET `/users/me`, PATCH `/users/me` | any user | PATCH changes name only |
| GET `/auctions` | public | query: q, category, status, sort (`endTime`\|`price`\|`-price`), page, limit |
| GET `/auctions/:id` | public | |
| GET `/auctions/mine` | seller | own listings |
| POST `/auctions` | seller | multipart form: title, description, category, startingPrice, minimumBidIncrement, startTime, endTime, image |
| PATCH/DELETE `/auctions/:id` | owner (or admin) | blocked with 409 once bids exist (non-admin) |
| POST `/auctions/:id/bids` | buyer/seller | body `{ amount }`; 201 accepted, 409 too low, 403 own auction, 400 not live |
| GET `/auctions/:id/bids` | public | bid history |
| GET `/bids/my-bids`, `/bids/my-wins` | any user | wins carry `paymentStatus: "not_processed"` |
| GET `/admin/dashboard` | admin | live counts from DB |
| GET `/admin/users` | admin | |
| PATCH `/admin/users/:id/status` | admin | `{ accountStatus: "active"\|"suspended" }` |
| GET `/admin/auctions` | admin | |
| DELETE `/admin/auctions/:id` | admin | cancels the auction (bids kept) |
