# BidHub – Online Auction System

A full-stack auction marketplace (React + Express + MongoDB) with buyer, seller and admin roles.

## Problem statement & objectives
Manual or ad-hoc auctions lack transparency and safe concurrent bidding. This project provides a web platform where sellers list items, buyers bid under enforced rules, and admins moderate the platform.

## Implemented features
JWT auth with bcrypt; role-based access; auction CRUD with image upload; bid validation (minimum, increment, deadline, no self-bidding); atomic concurrent-bid handling; idempotent auction completion and winner selection (no payments); search, filter, sort, pagination; buyer/seller/admin dashboards; countdown timers; confirmation dialogs.

## Stack
React 18 + Vite + React Router, plain CSS · Node + Express 4 · MongoDB + Mongoose · zod, helmet, express-rate-limit, multer.

## Setup
```bash
git clone <your-repo-url>
cd online-auction-system
cd server && npm install && cp .env.example .env   # edit JWT_SECRET and MONGODB_URI
cd ../client && npm install && cp .env.example .env
```
MongoDB: run a local instance (`mongodb://127.0.0.1:27017/online_auction`) or paste a MongoDB Atlas connection string into `MONGODB_URI`.

```bash
cd server && npm run seed:admin   # creates the admin from ADMIN_EMAIL / ADMIN_PASSWORD
cd server && npm run dev          # API on :5000
cd client && npm run dev          # UI on :5173
```

## Testing
`cd server && npm test` (uses an in-memory MongoDB; first run downloads a MongoDB binary, so it needs internet).

## Structure
`client/` (components, pages, context, services, utils) · `server/` (config, middleware, models, routes, services, validators, utils, tests, scripts) · `docs/`. Routes contain the controller logic; business rules live in `services/auctionService.js`.

## Docs
[API](docs/api-documentation.md) · [Architecture](docs/architecture.md)

## Screenshots
_Add screenshots here (home, auction details, dashboards)._

## Known limitations / future work
No payment integration; no real-time (polling every 10 s on detail page); no deployment config; no ESLint config yet; Bid insert is not in a transaction (see architecture.md); admin accounts are created only by the seed script.

## Contributing
Fork, create a feature branch, add tests, open a pull request.

## License
MIT – see `LICENSE`.
